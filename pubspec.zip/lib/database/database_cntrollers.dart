// ignore_for_file: non_constant_identifier_names

import 'dart:io';

import '/models/itme.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DBHElper {
  Database? _database;
  int Version_db = 1;

  String Table_Name_Harvesting = 'Harvesting_Tb';
  String id = 'id';
  String Name = 'Name';
  String Type = 'Type';
  String Price = 'Price';
  String Address = 'Address';
  String Images = 'Images';

  Future<Database?> get CreatDataBase async {
    if (_database != null) {
      return _database;
    } else {
      return _database = await initiolaizDatabase();
    }
  }

  Future<Database> initiolaizDatabase() async {
    Directory dir = await getApplicationDocumentsDirectory();
    String path = dir.path;
    return await openDatabase("$path/harveating.db", version: Version_db,
        onCreate: (db, version) async {
      await db.execute('''
  CREATE TABLE $Table_Name_Harvesting (
  $id INTEGER PRIMARY KEY AUTOINCREMENT,
  $Name TEXT ,
  $Type TEXT ,
  $Price REAL ,
  $Address TEXT ,
  $Images TEXT,
)
''');
    });
  }

  Future<int> InsertTable(itme harvesting) async {
    Database? db = await CreatDataBase;
    String query = '''
    INSERT INTO $Table_Name_Harvesting
    ($Name, $Type, $Price, $Address, $Images )
    VALUES
    (
      '${harvesting.Name}',
      '${harvesting.Type}',
      '${harvesting.price}',
      '${harvesting.Address}',
     '${harvesting.Images}',
    )
  ''';
    return await db!.rawInsert(query);
  }

  Future<int> DeletDataTable(int idH) async {
    final Database? db = await CreatDataBase;
    return await db!.delete(
      Table_Name_Harvesting,
      where: "$id=?",
      whereArgs: [idH],
    );
  }

  Future<int> UpdateDataTable(itme harvesting) async {
    final Database? db = await CreatDataBase;
    return await db!.update(
      Table_Name_Harvesting,
      harvesting.ToMap(),
      where: "$id=?",
      whereArgs: [harvesting.id],
    );
  }

  Future<void> DeleteALl() async {
    final Database? db = await CreatDataBase;
    return await db!.execute('DELETE FROM Harvesting_Tb;');
  }

  Future<List<itme>> ShowDataTable() async {
    final Database? db = await CreatDataBase;
    final List<Map<String, dynamic>> map =
        await db!.query(Table_Name_Harvesting);
    return List.generate(map.length, (i) {
      return itme(
        id: map[i][id],
        Name: map[i][Name],
        Type: map[i][Type],
        price: map[i][Price],
        Address: map[i][Address],
        Images: map[i][Images],
      );
    });
  }
}
